--spool
--notar el EXIT, sale del SQLPLUS
conn system/root
set pagesize 0
set linesize 100
set feedback off
set verify off
drop user &1 cascade;

create user &1 identified by &1;

--
grant dba to &1;
spool C:\Tarea4\ListObjUsu.html


select '<html><font size="10" color ="green">'||to_char(sysdate,'MM-DD-YYYY HH24:MI:SS')||'</font><br><br>'
from dual;

select '<font size="10" color ="blue">
Usuario:'||'&1'||'</font><br><br>'
from dual;

select '<font size="10" color ="blue">
Tipo Objeto:'||'&2'||'</font><br><br>'
from dual;
select '<table border="1"><tr><th>Lista de Objetos</th></tr>'
from dual;

select '<tr><td>'||object_name||'</td></tr>'
from   DBA_OBJECTS
where  object_type='&2' and OWNER='&1';


select '</html>'
from dual;
spool off
exit
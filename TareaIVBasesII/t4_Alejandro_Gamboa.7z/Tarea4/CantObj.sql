conn system/root
set pagesize 0
set linesize 100
set feedback off
set verify off

spool C:\Tarea4\CantObj.xml

select '<?xml version="1.0" encoding="UTF-8"?>'
from dual;
select '<reporte>'
from dual;
select '<fechayhora>'||to_char(sysdate,'MM-DD-YYYY HH24:MI:SS')||'</fechayhora>'
from dual;

select '<owner>'||owner||'</owner>','<cantidad>'||count(*)||'</cantidad>'
from   DBA_OBJECTS
group by owner
order by 1;

select '</reporte>'
from dual;
spool off
exit